# Executive Summary — Acme Fund

**Acme Fund** is the current category leader on GEVS Top-3 visibility.

## Visibility
- GEVS Top-3 Visibility: **50.0%** (Rank #1)
- GEVS Overall: 50.0% (1 total mentions)
- Most-cited source across all tested LLMs: **groww.in** (1 citations)

## Content Strategy
- Content gaps identified: 5
  (4 quick wins ≤30 days, 1 medium-term 31-90 days, 0 strategic 90+ days)
- Draft articles generated this run: 1

## Success Metrics (PRD KPIs)
- Citation Accuracy: 100.0% (target: 80.0%, met)
- Prompt Relevance (user-rated): not rated yet — no prompts rated this run
- Processing Speed: 0 min 0 sec (target: 3 min 0 sec, not met — see README on free-tier rate limits)
